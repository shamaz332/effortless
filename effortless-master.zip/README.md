run these commands

1 ) yarn
2 ) yarn start


Below are routes

http://localhost:3000/
http://localhost:3000/coindetail
http://localhost:3000/register
http://localhost:3000/welcome
http://localhost:3000/welcome/firsttime
http://localhost:3000/welcome/gimini
http://localhost:3000/welcome/binance
http://localhost:3000/welcome/coinbase
http://localhost:3000/welcome/firsttime/bitski
http://localhost:3000/welcome/firsttime/argantapp
http://localhost:3000/welcome/firsttime/metamask

